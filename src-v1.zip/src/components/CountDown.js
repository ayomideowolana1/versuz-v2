import React, { useState, useEffect } from 'react';

const Countdown = ({ targetTime }) => {
  const calculateTimeLeft = () => {
    const difference = targetTime - new Date().getTime();
    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / (1000 * 60)) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      };
    }

    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearTimeout(timer);
  });

  const { hours, minutes, seconds } = timeLeft;

  return (
    <div>
      <span>{hours.toString().padStart(2, '0')} : </span>
      <span>{minutes.toString().padStart(2, '0')}  </span>
      {/* <span>{seconds.toString().padStart(2, '0')}</span> */}
    </div>
  );
};

export default Countdown;