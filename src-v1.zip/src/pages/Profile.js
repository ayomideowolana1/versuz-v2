import React from "react";
import Nav from "../components/Nav";
import "../styles/profile.css";
import { useSelector, useDispatch } from "react-redux";
import UserGames from "../components/UserGames";

export default function Profile() {
  const username = useSelector((state) => state.auth.username);
  return (
    <>
      <Nav />
      <div className="profile">
        <div className="account">
          <img src="" alt="" />
          <span className="username">@{username}</span>
          <span className="rank">Idan</span>
        </div>
        <div className="wallet">
          {/* balance,earnings,deposit,withdraw */}
          <p>Bet balance</p>
          <div className="balance">
            <span>₦ 15,000</span>
            <button>Deposit</button>
          </div>
          <p>Earnings</p>
          <div className="earnings">
            <span>₦ 10,000</span>
            <button>
              
              Withdraw
            </button>
          </div>
        </div>
        <div className="stats">
          <div className="games-won">
            <p>Games Won</p>
            <h1>
              350<span className="small">/400</span>
            </h1>
          </div>
          <div className="win-percentage">
            <p>Win Percentage</p>
            <h1>75%</h1>
          </div>
          <div className="odds-won">
            <p>Odds Won</p>
            <h1>270</h1>
          </div>
          <div className="streak">
            <p>Longest Win Streak</p>
            <h1>
              15 <span className="small">(ongoing)</span>
            </h1>
          </div>
        </div>
        <UserGames />
      </div>
    </>
  );
}
