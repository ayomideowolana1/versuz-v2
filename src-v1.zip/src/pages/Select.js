import React, { useEffect, useState, useRef } from "react";
import "../styles/explore.css";
import PageTitle from "../components/PageTitle";
import Nav from "../components/Nav";
import { v4 as uuidv4 } from "uuid";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Match, Canvas } from "../components/Match";
import SelectGamesCanvas from "../components/SelectGamesCanvas";

import {
  getCompetitionsAsync,
  getCompetitionFixturesAsync,
  setActiveCompetitionName,
} from "../redux/slices/selectSlice";
import { setPairData } from "../redux/slices/ticketSlice";
import { useLocation } from "react-router-dom";
import Competitions from "../components/Competitions";


function LoadingComps() {
  return (
    <span
      className="btn"
      style={{
        color: "black",
        gap: "10px",
        display: "flex",
        alignItems: "center",
      }}
      type="button"
      disabled
    >
      <span
        className="spinner-border spinner-border-sm"
        role="status"
        aria-hidden="true"
      ></span>
      Loading competitions
    </span>
  );
}



function LoadingFixtures(props) {
  const { name } = props;
  return (
    <div className="games">
      <span
        className="btn"
        style={{
          color: "black",
          gap: "10px",
          display: "flex",
          alignItems: "center",
        }}
        type="button"
        disabled
      >
        <span
          className="spinner-border spinner-border-sm"
          role="status"
          aria-hidden="true"
        ></span>
        Loading {name} Fixtures
      </span>
    </div>
  );
}

export default function Select() {
  const dispatch = useDispatch();
  const location = useLocation();
  const { id } = useParams();

  const { competitions, gamesToDisplay, activeCompetitionName } = useSelector(
    (state) => state.select
  );

  const loadingCompetitions = useSelector(
    (state) => state.select.competitionsState.isLoading
  );

  const games = useSelector((state) => state.games.data);
  const { view } = useSelector((state) => state.select.view);

  const loadingFixtures = useSelector(
    (state) => state.select.fixturesState.isLoading
  );

  const [activeCompetiton, setActiveCompetiton] = useState(1);

  const closeOffCanvasRef = useRef();
  const showCompetitionsRef = useRef();

  const [showOffCanvas, setShowOffCanvas] = useState(true);

  useEffect(() => {
    // showCompetitionsRef.current.click();
    const filter = games.filter((game) => game.id == id);
    if (filter.length) {
      const stake = filter[0].stake;
      dispatch(setPairData({ id, stake }));
    }
    dispatch(getCompetitionsAsync());
    dispatch(getCompetitionFixturesAsync(activeCompetiton));
  }, []);

  const handleCompetitionChange = (e) => {
    closeOffCanvasRef.current.click();
    const { id } = e.target;
    const { name } = e.target.dataset;
    setActiveCompetiton(id);
    dispatch(getCompetitionFixturesAsync(id));
    dispatch(setActiveCompetitionName({ name, id }));
  };

  const currentFixture = useSelector((state) => state.select.currentFixture);

  return (
    <>
      <PageTitle title="Versuz - Choose Games" />
      <Nav />
      <main className="explore-main">
        <aside className="explore ">
          <Competitions />
        </aside>
        <aside className="explore d-none">
          <h2 style={{ fontSize: ".9rem" }}>Pick your bets ({id})</h2>

          {/* OPTIONS SM */}
          <div className="options select">
            {loadingCompetitions ? (
              <LoadingComps />
            ) : (
              <button
                className="btn btn-primary"
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasRight"
                aria-controls="offcanvasRight"
                ref={showCompetitionsRef}
              >
                {activeCompetitionName}
              </button>
            )}

            <div
              className="offcanvas offcanvas-end "
              tabIndex="-1"
              id="offcanvasRight"
              aria-labelledby="offcanvasRightLabel"
            >
              <div className="offcanvas-header">
                <h5 id="offcanvasRightLabel">Choose competition</h5>
                <button
                  type="button"
                  className="btn-close text-reset"
                  data-bs-dismiss="offcanvas"
                  aria-label="Close"
                  ref={closeOffCanvasRef}
                >
                  x
                </button>
              </div>
              <div className="offcanvas-body">
                {competitions.map((competition) => {
                  return (
                    <button
                      key={competition.id}
                      id={competition.id}
                      data-name={competition.competition_name}
                      onClick={handleCompetitionChange}
                      className={
                        activeCompetiton == competition.id ? "active" : ""
                      }
                    >
                      <img
                        src={`${process.env.REACT_APP_BASE_URL}${competition.competition_emblem}`}
                        alt=""
                      />
                      <span>{competition.competition_name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {loadingCompetitions ? (
            ""
          ) : loadingFixtures ? (
            <LoadingFixtures name={activeCompetitionName} />
          ) : (
            <div className="games">
              {gamesToDisplay.length > 0 ? (
                gamesToDisplay.map((competition) => (
                  <Match data={competition} key={uuidv4()} />
                ))
              ) : (
                <p>There are no fixtures to display</p>
              )}

              {currentFixture ? <SelectGamesCanvas /> : ""}
            </div>
          )}
        </aside>
        {/* <aside className="matches selections">
          <h1>Match ID: </h1>
        </aside> */}
      </main>
    </>
  );
}

{
  /* OPTIONS LG */
}
{
  /* <div className="options buttons">
            {loadingCompetitions ? (
              <LoadingComps />
            ) : (
              competitions.map((competition) => {
                // return (
                //   <button
                //     key={competition.id}
                //     id={competition.id}
                //     data-name={competition.competition_name}
                //     onClick={handleCompetitionChange}
                //     className={
                //       activeCompetiton == competition.id ? "active" : ""
                //     }
                //   >
                //     <img
                //       src={`${process.env.REACT_APP_BASE_URL}${competition.competition_emblem}`}
                //       alt=""
                //     />
                //   </button>
                // );
              })
            )}

            {}
          </div> */
}
