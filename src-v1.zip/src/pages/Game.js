import React from 'react'

export default function Game() {
  return (
    <div>Game</div>
  )
}
