import React, { useEffect, useLayoutEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import Nav from "../components/Nav";
import PageTitle from "../components/PageTitle";
import highFive from "../images/Charco High Five.png";
import "../styles/explore.css";
import Game from "../components/Game";
import { getUnpairedGamesAsync } from "../redux/slices/gamesSlice";
import ExploreNavButton from "../components/ExploreNavButton";
import { Link, useNavigate } from "react-router-dom";
import icon from "../images/versuz-icon.svg";
import BottomNav from "../components/BottomNav";

function CreateNew(props) {
  const { clickEvent } = props;
  return (
    <div>
      <img src={highFive} alt="" />
      <h3>You don't have any games</h3>

      <button onClick={clickEvent}>
        <svg
          width="25"
          height="26"
          viewBox="0 0 25 26"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M22.3392 14.4008H14.0693V22.6707H11.3126V14.4008H3.04272V11.6442H11.3126V3.37427H14.0693V11.6442H22.3392V14.4008Z"
            fill="white"
          />
        </svg>

        <span style={{ textDecoration: "none" }}>Create new game</span>
      </button>
    </div>
  );
}

function UserGames(props) {
  const { games } = props;
  return (
    <>
      {games.map((game) => {
        return (
          <div key={game.id} className="paired-game">
            <div className="section">
              <div className="score">
                <img src="" alt="" />
                <span>7 - 5</span>
                <img src="" alt="" />
              </div>
              <div className="payout">
                <h3>₦{game.stake * 2}</h3>
                <p>Potential Payout</p>
              </div>
            </div>
            <div className="section two">
              <div>
                <h3>{game.end_date.split("T")[1]}</h3>
                <p>* games left</p>
              </div>

              <div>
                <p>status</p>
                <span className="ongoing">ON-GOING</span>
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}

function Loader(props) {
  const { text } = props;
  return (
    <div className="loader">
      <img src={icon} alt="" />
      <p>{text}</p>
    </div>
  );
}

export default function Explore() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loggedIn = useSelector((state) => state.auth.loggedIn);
  const token = useSelector((state) => state.auth.userAuthKey);

  useEffect(() => {
    token == ""
      ? dispatch(getUnpairedGamesAsync())
      : dispatch(getUnpairedGamesAsync(token));
    // console.log(token)
  }, [loggedIn]);

  const [view, setView] = useState("1v1");
  const handleViewChange = (e) => {
    setView(e.target.id);
  };

  const buttons = [
    // { id: "free", buttonText: "Free" },
    { id: "1v1", buttonText: "1 v 1" },
    { id: "pool", buttonText: "Pool" },
    { id: "tournament", buttonText: "Tournament" },
  ];

  const unpairedGames = useSelector((state) => state.games.data);
  const userGames = useSelector((state) => state.games.userGames);
  const isLoading = useSelector((state) => state.games.isLoading);

  const handleCreateNewGameClick = () => {
    // navigate("/select/?id=new");
  };

  return (
    <>
      <PageTitle title="Versuz - Join our Online Platform to Bet Against Fellow Enthusiasts" />
      <Nav />
      <main className="explore-main">
        <aside className="explore">
          {/* <h2>Explore</h2> */}

          {/* options lage screens */}
          <div className="options button">
            {buttons.map((button) => (
              <ExploreNavButton
                key={button.id}
                data={button}
                view={view}
                clickHandler={handleViewChange}
              />
            ))}
          </div>

          {/* options small screens */}

          {unpairedGames.filter((game) => game.type == view).length > 0 ? (
            <div className="games">
              {unpairedGames
                .filter((game) => game.type == view)
                .map((game) => {
                  return <Game key={game.id} data={game} />;
                })}
            </div>
          ) : (
            <div className="games">
              {isLoading ? (
                <Loader text={`Loading ${view} games`} />
              ) : (
                <h1> No {view} games at this moment </h1>
              )}
            </div>
          )}
        </aside>

        <aside className="matches">
          <div className="top">
            <h2>Your games </h2>
            {loggedIn && userGames.length > 0 && (
              <button onClick={handleCreateNewGameClick}>
                <svg
                  width="25"
                  height="26"
                  viewBox="0 0 25 26"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M22.3392 14.4008H14.0693V22.6707H11.3126V14.4008H3.04272V11.6442H11.3126V3.37427H14.0693V11.6442H22.3392V14.4008Z"
                    fill="white"
                  />
                </svg>
              </button>
            )}
          </div>
          <div className="inner">
            {loggedIn ? (
              userGames.length > 0 ? (
                <UserGames games={userGames} />
              ) : (
                <CreateNew clickEvent={handleCreateNewGameClick} />
              )
            ) : (
              <CreateNew clickEvent={handleCreateNewGameClick} />
            )}
          </div>
        </aside>
        <BottomNav />
      </main>
    </>
  );
}
