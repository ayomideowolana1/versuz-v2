import React, { useRef } from "react";
import Nav from "../components/Nav";
import "../styles/new-game.css";
import { FaSearch } from "react-icons/fa";
import swords from "../images/swords.png";
import stadium from "../images/stadium.png";
import cup from "../images/cup.png";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function NewGame() {
  const inputRef = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate()

  const focus = () => {
    inputRef.current.focus();
  };

  const options = [
    {
      id: 1,
      name: "1v1",
      text: "Only One Can Triumph!",
      img: swords,
      gradient: "blue",
    },
    {
      id: 2,
      name: "Pool",
      text: "Be the Last One Standing!",
      img: stadium,
      gradient: "orange",
    },
    {
      id: 3,
      name: "Tournament",
      text: "Climb the Ranks to Glory!",
      img: cup,
      gradient: "purple",
    },
  ];

  const handleNewGameClick = (e) => {
    const { type } = e.target.dataset;
    navigate(`/select/new-${type.toLowerCase()}`)
  };

  return (
    <>
      <Nav />
      <div className="new-game">
        <div className="search">
          <h3>Join game</h3>
          <div className="input-cont" onClick={focus}>
            <FaSearch />
            <input type="text" ref={inputRef} placeholder="Search for a game" />
            {/* <button>GO</button> */}
          </div>
        </div>

        <div className="buttons">
          <h3>Create new game</h3>
          <div className="options">
            {options.map((opt) => (
              <button
                key={opt.id}
                data-type={opt.name}
                className={`card ${opt.gradient}`}
                onClick={handleNewGameClick}
              >
                <div className="text cont" style={{ pointerEvents: "none" }}>
                  <h1>{opt.name}</h1>
                  <p>{opt.text}</p>
                </div>
                <div className="img cont">
                  <img src={opt.img} alt="" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
