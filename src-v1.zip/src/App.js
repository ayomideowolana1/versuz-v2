import { Route, Routes, Navigate, useNavigate } from "react-router-dom";
import Login from "./pages/Login";
import Explore from "./pages/Explore";
import Select from "./pages/Select";
import { useSelector, useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { getSavedCridentials } from "./redux/slices/authSlice";
import NewGame from "./pages/NewGame";
import Profile from "./pages/Profile";
import Game from "./pages/Game";
import Ticket from "./pages/Ticket";
import TicketCreated from "./pages/TicketCreated";
import MatchPage from "./pages/MatchPage";

function ProtectedRoute(props) {
  const { element, path } = props;

  return <Route path={path} element={<element />} />;
}

function App() {
  const dispatch = useDispatch();

  const loggedIn = useSelector((state) => state.auth.loggedIn);
  const loggedOut = useSelector((state) => state.auth.loggedOut);

  const [allowOtherRoutes, setAllowOtherRoutes] = useState(false);

  const navgate = useNavigate();
  useEffect(() => {
    if (loggedIn && !loggedOut) {
      setAllowOtherRoutes(true);
    } else {
      setAllowOtherRoutes(false);
    }
  }, [loggedIn]);

  useEffect(() => {
    dispatch(getSavedCridentials());
  }, [loggedOut]);

  return (
    <div>
      <Routes>
        <Route path="/" element={<Explore />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/login" element={<Login />} />

        <Route path="/new-game" element={<NewGame />} />

        <Route path="/select" element={<Select />}>
          <Route path="/select:id" element={<Select />} />
        </Route>

        <Route path="/game" element={<Game />} />
        <Route path="/match/:id" element={<MatchPage />} />

        <Route path="/pair/:id" element={<TicketCreated />} />

        <Route path="/ticket" element={<Ticket />} />

        <Route path="/profile" element={<Profile />} />

        <Route path="*" element={<Navigate to="/" />} />
        
      </Routes>
    </div>
  );
}

export default App;

/*


{allowOtherRoutes ? (
          <>
            <Route path="select" element={<Navigate to={"/new-game"} />} />
            <Route path="select/:id" element={<Select />} />

            <Route path="game" element={<Game />} />
            <Route path="profile" element={<Profile />} />
          </>
        ) : (
          ""
        )}
*/
