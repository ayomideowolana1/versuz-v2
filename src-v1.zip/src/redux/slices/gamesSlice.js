import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getUnpairedGamesAsync = createAsyncThunk(
  "getUnpairedGames",
  async (payload) => {
    const url = process.env.REACT_APP_BASE_URL;
    let config;
    if (payload === "") {
      config = {
        method: "GET",
        headers: {
          reactkey: process.env.REACT_APP_AUTH_KEY,
        },
      };
    } else {
      config = {
        method: "GET",
        headers: {
          reactkey: process.env.REACT_APP_AUTH_KEY,
          Authorization: `Token ${payload}`,
        },
      };
    }
    const response = await fetch(url, config).then((data) => data.json());
    // console.log(response);

    return response;
  }
);

export const getMatchAsync = createAsyncThunk(
  "getMatchAsync",
  async (payload) => {
    const url = `${process.env.REACT_APP_BASE_URL}/match/${payload}`;
    let config;
    if (payload) {
      config = {
        method: "GET",
        headers: {
          reactkey: process.env.REACT_APP_AUTH_KEY,
        },
      };
    } 
    // else {
    //   config = {
    //     method: "GET",
    //     headers: {
    //       reactkey: process.env.REACT_APP_AUTH_KEY,
    //       // Authorization: `Token ${payload}`,
    //     },
    //   };
    // }
    // console.log(url)
    const response = await fetch(url, config).then((data) => data.json());
    console.log(response);

    return response;


  }
);

export const gamesSlice = createSlice({
  name: "games",
  initialState: {
    isLoading: false,
    isErr: false,
    data: [],
    userGames: [],
    loadingMatchData:false,
    matchData:{},
    
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getUnpairedGamesAsync.pending, (state, action) => {
      state.isLoading = true;
      state.isErr = false;
    });
    builder.addCase(getUnpairedGamesAsync.rejected, (state, action) => {
      state.isLoading = false;
      state.isErr = true;
    });
    builder.addCase(getUnpairedGamesAsync.fulfilled, (state, action) => {
      // console.log(action.payload)
      state.isLoading = false;
      state.isErr = false;
      state.data = action.payload.unpaired_betcodes;
      if(action.payload.user_games){

        state.userGames = action.payload.user_games;
      }
    });
    builder.addCase(getMatchAsync.pending, (state, action) => {
      state.loadingMatchData = true;
    });
    builder.addCase(getMatchAsync.rejected, (state, action) => {
      state.loadingMatchData = false;
    });
    builder.addCase(getMatchAsync.fulfilled, (state, action) => {
      state.loadingMatchData = false;
      state.matchData = action.payload;
    });
  },
});

// Action creators are generated for each case reducer function
export const { getGames, changView } = gamesSlice.actions;

export default gamesSlice.reducer;

