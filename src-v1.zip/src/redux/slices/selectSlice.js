import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { v4 as uuidv4 } from "uuid";
import axios from "axios";

// Handles asynchronus updates of authentication state
export const getCompetitionsAsync = createAsyncThunk(
  "getCompetitionsAsync",
  async (payload) => {
    const url = process.env.REACT_APP_SELECT_COMPETITIONS;
    const config = {
      method: "GET",
      headers: {
        reactkey: process.env.REACT_APP_AUTH_KEY,
        "Content-Type": "application/json",
      },
    };
    const response = await fetch(url, config).then((data) => data.json());
    // console.log(response);

    return response;
  }
);

export const getCompetitionFixturesAsync = createAsyncThunk(
  "getCompetitionFixturesAsync",
  async (payload) => {
    const url = `${process.env.REACT_APP_GET_FIXTURES}/${payload}`;
    const config = {
      method: "GET",
      headers: {
        reactkey: process.env.REACT_APP_AUTH_KEY,
        "Content-Type": "application/json",
      },
    };
    const response = await fetch(url, config).then((data) => data.json());
    return { fixtures: response, id: payload };
  }
);

export const selectSlice = createSlice({
  name: "select",
  initialState: {
    competitionsState: {
      isErr: false,
      isLoading: false,
      errMessage: "",
    },
    fixturesState: {
      isErr: false,
      isLoading: false,
      errMessage: "",
    },
    competitions: [],
    activeCompetitionName: "",
    activeCompetitionId: "",
    fixtures: [],
    view: "",
    gamesToDisplay: [],
    currentFixture: null,
    showOffCanvas: false,
  },
  reducers: {
    setActiveCompetitionName: (state, action) => {
      return {
        ...state,
        activeCompetitionName: action.payload.name,
        activeCompetitionId: action.payload.id,
      };
    },
    showFixtures: (state, action) => {
      console.log(action.payload);
      return {
        ...state,
        currentFixture: action.payload,
        showOffCanvas: true,
      };
    },
    hideFixtures: (state, action) => {
      return {
        ...state,
        showOffCanvas: false,
      };
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getCompetitionsAsync.pending, (state, action) => {
      state.competitionsState.isLoading = true;
    });

    builder.addCase(getCompetitionsAsync.rejected, (state, action) => {
      state.isErrComps = true;
      state.isLoadingComps = false;
    });

    builder.addCase(getCompetitionsAsync.fulfilled, (state, action) => {
      state.competitionsState.isLoading = false;
      state.competitions = action.payload;
      state.activeCompetitionName = action.payload[0].competition_name;
    });

    builder.addCase(getCompetitionFixturesAsync.pending, (state, action) => {
      state.fixturesState.isLoading = true;
    });

    builder.addCase(getCompetitionFixturesAsync.rejected, (state, action) => {
      state.fixturesState.isLoading = false;
      state.fixturesState.isErr = true;
      
    });

    builder.addCase(getCompetitionFixturesAsync.fulfilled, (state, action) => {
      state.fixturesState.isLoading = false;
      const { id, fixtures } = action.payload;
      // console.log(id, fixtures);

      state.fixtures[id] = fixtures;
      state.gamesToDisplay = state.fixtures[id];

      // if(!state.competitions[id - 1].competition_name){

      // }else{

      //   state.activeCompetitionName = state.competitions[id - 1].competition_name
      // }
    });
  },
});

export const { setActiveCompetitionName, showFixtures, hideFixtures } =
  selectSlice.actions;
export default selectSlice.reducer;
